# IntegradorVippWebService
Faz a leitura de uma planilha em Excel e alimenta o serviço Soap
